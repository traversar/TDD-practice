let assert = require('assert');
let {returnThree, reciprocal} = require('../problems/number-fun');

describe('return three', ()=>{
    it('This function returns the number 3',()=>{
        let out = 3;

        let res = returnThree();

        assert.deepEqual( out, res);
    })

})

describe('reciprocal', ()=>{
    it('should return the reciprocal of a given number',()=>{
        let out = 1/3;
        let res = reciprocal(3);

        assert.deepEqual(out,res);
    })
    // context('should throw a type error if outside of range 1- 1,000,000', ()=>{

    //     assert.throws(()=>reciprocal(0),TypeError);
    //     assert.throws(()=>reciprocal(-1),TypeError);
    //     assert.throws(()=>reciprocal(1000001),TypeError);
    // })

})
