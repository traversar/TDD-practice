let { myMap } = require('../problems/my-map');
let chai = require('chai');
let spies = require('chai-spies');
chai.use(spies);
const expect = chai.expect;

describe('myMap function', ()=>{
    let arr;
beforeEach('set new arr instance',()=>{
    arr= [1,2,3];
});
it('should return an array',()=>{
    let res = myMap(arr,ele=>ele*2);
    expect(res).to.be.an('Array');
})
it('should return an array of the translated properties', () => {
    let res = myMap(arr, ele => ele*2);
    expect(res).to.eql([2,4,6]);
})
it('the map should not muatate the array',()=>{
    myMap(arr, (el) => el*2);
    expect(arr).to.eql([1,2,3]);
});
it('does not call the builtin Array#map function', () => {
    let mapSpy = chai.spy.on(arr, 'map');
    myMap(arr,(ele)=>{ ele*2});
    expect(mapSpy).to.have.been.called.exactly(0);

})
it('calls the cb the length of the array', () => {
    let spy = chai.spy.on(el=>{el});
    myMap(arr,spy);
    expect(spy).to.have.been.called.exactly(3);

})
})
