let { reverseString } = require('../problems/reverse-string')
const chai = require('chai');
const expect = chai.expect;
const spies = require('chai-spies');
chai.use(spies);

describe('reverseString Function', function() {
    it('should return the input reversed', () => {
        let input = "fun";
        let output = "nuf";

        let result = reverseString(input);

        expect(result).to.eql(output);
    });

    it('should throw a TypeError if invoked with an argument that is not a string', () => {
        let input = 5;

        expect(()=>reverseString(input)).to.throw(TypeError);
    })
});
