let {Person} = require('../problems/person');
const chai = require('chai');
const expect = chai.expect;
const spies = require('chai-spies');
chai.use(spies);

describe('Person Class', () => {
    beforeEach('new person object', () => {
        person1 = new Person('John', 50);
        person2 = new Person('Sally', 30)
    })

    describe('Person Constructor', ()=>{
        it('should intake name and age and set them as properties', () => {
            expect(person1.name).to.eql('John');
            expect(person1.age).to.eql(50);
        })
    })

    describe('Say Hello fuction', ()=>{
        it('should return a string saying hello to the named person', ()=>{
            let res = person1.sayHello();
            expect(res).to.be.eql('Hi, John');
        })

    })

    describe('Visit function', () => {
        it('should return a string stating this instance has visited passed-in person', () => {
            let res = person1.visit(person2);
            expect(res).to.be.eql('John visited Sally');
        })
    });
    describe('Visit function', () => {
        it('should return a string stating this instance has visited passed-in person', () => {
            let res = person1.switchVisit(person2);
            expect(res).to.be.eql('Sally visited John');
        })

    });

    describe('prototype.update(obj) method', () => {
        context('argument is a valid object', () => {
            it("should update instance values to match passed-in object's values", () => {
                person1.update(person2);
                expect(person1.name).to.be.eql('Sally');
                expect(person1.age).to.be.eql(30);
            })
        });

        context('argument is not a valid object', () => {
            it('should throw a new TypeError with a clear message', () => {
                expect(() => person1.update(undefined)).to.throw(TypeError)
            })
        });
    });

    describe('prototype.tryUpdate(obj) method', () => {
        it('try to Update if it works return true',()=>{

            let res = person1.tryUpdate(person2);
            expect(res).to.be.true;
        })
        context(`if it doesn't work return false`, ()=>{
            it('',()=>{


                let res = person1.tryUpdate({});
                expect(res).to.be.false;
            })
            })
        });

    describe('greetAll(obj) method', () => {
        it('should return an array of strings saying hi to each person in passed-in person array', () => {
            let personArr = [person1, person2];
            expect(Person.greetAll(personArr)).to.be.eql(['Hi, John', 'Hi, Sally']);
        })
        it('should call sayHello the length of the array times', () => {
            let personArr = [person1, person2];
            let sayHelloSpy = chai.spy.on(Person.prototype, 'sayHello');
            Person.greetAll(personArr);
            expect(sayHelloSpy).to.have.been.called.twice;
        })
    })
});
