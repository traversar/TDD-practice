function returnThree(){
    return 3;
}
function reciprocal(x){
    return 1/x;
}
module.exports = {
    returnThree,
    reciprocal
}
