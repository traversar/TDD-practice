function myMap(arr,cb){
    let newArr = []
    arr.forEach(element => {
        newArr.push(cb(element));

    });
    return newArr;

}
module.exports = {
    myMap
}
